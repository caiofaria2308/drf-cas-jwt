from django.apps import AppConfig


class DrfCasJwtConfig(AppConfig):
    name = "drf_cas_jwt"
